package projet;

abstract public class UnaryExpr extends Expr {

}
