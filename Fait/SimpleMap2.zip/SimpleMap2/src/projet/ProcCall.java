package projet;

public class ProcCall extends Statement
{
  Expr expr;

  public ProcCall(Expr expr)
  {
    this.expr = expr;
  }
}
