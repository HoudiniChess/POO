package projet;

public abstract class Statement
{}
