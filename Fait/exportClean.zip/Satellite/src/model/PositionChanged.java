package model;

import java.util.EventObject;

public class PositionChanged extends EventObject{

	public PositionChanged(Object arg0) {
		super(arg0);
	}

}
