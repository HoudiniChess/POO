package model;

public class PositionChangedEvent {

}
