package simulation;

public class GrBalise extends GrElementMobile {
	

}
