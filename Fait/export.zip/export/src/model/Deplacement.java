package model;

import simulation.GrElementMobile;

public abstract class Deplacement {

	abstract public void bouge(ElementMobile target) ;

}
