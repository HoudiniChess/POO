package model;

public class System {

}
