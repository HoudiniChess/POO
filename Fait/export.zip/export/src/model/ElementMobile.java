package model;

import java.util.Observable;

public class ElementMobile extends Observable {
	Deplacement depl;
	Point position;
	
	public void bouge () {
		this.depl.bouge(this);
		this.notifyObservers(this);
	}
	
	public void setDeplacement(Deplacement depl) {
		this.depl = depl;
	}

}
