package model;

import simulation.GrElementMobile;

public class DeplHorizontal extends Deplacement {

	@Override
	public void bougeElementMobile target) {
		target.setX(target.getX()+ 3);
	}

}
