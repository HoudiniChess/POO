package model;

public class Balise extends ElementMobile {

}
