package hello2.metamodel;

public interface MMEntity {
	void accept (Visitor visitor) ;

}
