package hello2.metamodel;

public interface Visitor {
	public void visitDay(Day day);
	public void visitMeeting(Meeting meeting);
	public void visitPratice(Practice practice);
	public void visitSchedule(Schedule schedule);
	public void visitSleeping(Sleeping sleeping);
}
